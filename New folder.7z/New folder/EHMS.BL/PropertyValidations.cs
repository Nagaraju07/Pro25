﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using EHMS.Entity;

namespace EHMS.BL
{
    class PropertyValidations
    {
        public static bool ValidateProperty(Property property)
        {
            bool isValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //if (!Regex.IsMatch(property.PropertyId.ToString(), "[0-9]"))
                //{
                //    message.Append("Property Id should not contain characters");
                //    isValidated = false;
                //}

                //Validation for property name- should not contain digits
                if (!Regex.IsMatch(property.PropertyName, "[A-Z,a-z]"))
                {
                    message.Append("Property name should contain only characters");
                    isValidated = false;
                }

                if (property.PropertyName == string.Empty)
                {
                    message.Append("Property name should not be empty");
                    isValidated = false;
                }

                if (!Regex.IsMatch(property.PropertyType, "[A-Z,a-z]"))
                {
                    message.Append("Property type should contain only characters");
                    isValidated = false;
                }

                if (property.PropertyType == string.Empty)
                {
                    message.Append("Property type should not be empty");
                    isValidated = false;
                }

                if (!Regex.IsMatch(property.PropertyOption, "[A-Z,a-z]"))
                {
                    message.Append("Property option should contain only characters");
                    isValidated = false;
                }

                if (property.PropertyOption == string.Empty)
                {
                    message.Append("Property option should not be empty");
                    isValidated = false;
                }


                if (property.Description == string.Empty)
                {
                    message.Append("Property Description should not be empty");
                    isValidated = false;
                }

                if (property.Address == string.Empty)
                {
                    message.Append("Property Address should not be empty");
                    isValidated = false;
                }


                if (!Regex.IsMatch(property.PropertyType, "[A-Z,a-z]"))
                {
                    message.Append("Property type should contain only characters");
                    isValidated = false;
                }

                if (property.PropertyType == string.Empty)
                {
                    message.Append("Property type should not be empty");
                    isValidated = false;
                }





                if (isValidated == false)
                    throw new PropertyException(message.ToString());


            }
            catch (PropertyException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return isValidated;
        }

        //Adding Property details method
        public int AddProperty_BL(Property newProperty)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateProperty(newProperty))
                {
                    rowsAffected = AddProperty_DAL(newProperty);
                }
            }
            catch (PropertyException ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;
        }

    }
}

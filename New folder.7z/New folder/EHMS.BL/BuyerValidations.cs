﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHMS.Entity;
using System.Data;
using System.Data.SqlClient;
using System.Text.RegularExpressions;

namespace EHMS.BL
{
    class BuyerValidations
    {

        public static bool ValidateBuyer(Buyer buyer)
        {
            bool isValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                //Validation for buyer Id -should contain only digits
                if (!Regex.IsMatch(buyer.BuyerId.ToString(),"[0-9]{5,}"))
                {
                    message.Append("BuyerId should not contain characters \n");
                    isValidated = false;
                }

                //Validation for Buyer Id - should not be empty
                if (buyer.BuyerId.ToString() == string.Empty)
                {
                    message.Append("BuyerId should not be empty \n");
                    isValidated = false;
                }

                //Validation for Buyer First name - should not be empty
                if (buyer.FirstName==string.Empty)
                {
                    message.Append("Buyer First Name should not be empty \n");
                    isValidated = false;
                }

                //Validation for Buyer Firstname  - should contain only characters
                if (!Regex.IsMatch(buyer.FirstName, "[A-Z][a-z]{3,}"))
                {
                    message.Append("Buyer FirstName should not contain digits \n");
                }

                // Validation for Buyer lastname - can be emp[ty or should contain only characters
                if (!Regex.IsMatch(buyer.LastName, "[A-Z][a-z]{0,}"))
                {
                    message.Append("Buyer Lastname should not contain digits \n");
                }

                //Validation for Buyer Date of birth - should not be empty
                if (buyer.DateOfBirth.ToString()==string.Empty)
                {
                    message.Append("Buyer Date of Birth should not be Empty");
                }

                //Validation for Buyer's age - should be more than 21 years
                if (DateTime.Now.Year-buyer.DateOfBirth.Year>=21)
                {
                    message.Append("Buyer doesnot have enough age,minimum age is ' 21 ' \n");
                }

                //Validation for Buyer phone no. - should start with 6/7/8/9 and should contain 10 digits
                if (!Regex.IsMatch(buyer.PhoneNo.ToString(), "[6,7,8,9][0-9]{9,}"))
                {
                    message.Append("Buyer phone number should not contain characters and should be 10 digits \n");
                    isValidated = false;
                }

                //Validation for buyer phone no. - should not be empty 
                if (buyer.PhoneNo.ToString() == string.Empty)
                {
                    message.Append("Buyer phone number should not be empty \n");
                    isValidated = false;
                }

                //Validation for buyer Email Id
                if (!Regex.IsMatch(buyer.EmailId.ToString(),"[A-Z,a-z][0-9,a-z,A-Z]{5,}[@]{1} "))
                {
                    message.Append("Email id is not valid, should be of form 'someone@something.com' \n");
                    isValidated = false;
                }

                //Validation for Buyer Email ID - should not be empty
                if (buyer.EmailId == string.Empty)
                {
                    message.Append("Buyer Email Id should not be empty \n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new BuyerException(message.ToString());

            }
            catch (BuyerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isValidated;
        }

        //Adding Buyer details method
        public int AddBuyer_BL(Buyer newBuyer)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateBuyer(newBuyer))
                {
                    rowsAffected = AddBuyer_DAL;
                }
            }
            catch (BuyerException ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;
        }


    }
}

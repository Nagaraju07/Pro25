﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using EHMS.Entity;
using System.Text.RegularExpressions;

namespace EHMS.BL
{
    public class UserValidations
    {
        public static bool ValidateUser(User user)
        {
            bool isValidated = true;
            StringBuilder message = new StringBuilder();
            try
            {
                // Validation for User name -should not be empty
                if (user.UserName == string.Empty)
                {
                    message.Append("Username should not be empty \n");
                    isValidated = false;
                }

                //Validation for User name - should contain only characters
                if (!Regex.IsMatch(user.UserName, "[A-Z,a-z]{3,}"))
                {
                    message.Append("Username should contain only alphabets \n");
                    isValidated = false;
                }

                // Valiadation for User password - should not be empty
                if (user.Password == string.Empty)
                {
                    message.Append("Password should not be blank \n");
                    isValidated = false;
                }
                                           
                if (isValidated == false)
                    throw new UserException(message.ToString());

            }
            catch (UserException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
            return isValidated;
        }

        //Adding User details method
        public static int AddUser_BL(User newUser)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateUser(newUser))
                {
                    rowsAffected = AddUser_DAL(newUser);
                }
            }
            catch (UserException ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;
        }

    }
}

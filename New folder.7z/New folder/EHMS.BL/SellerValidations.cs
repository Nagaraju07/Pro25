﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EHMS.Entity;
using System.Text.RegularExpressions;
using System.Data;
using System.Data.SqlClient;

namespace EHMS.BL
{
    public class SellerValidations
    {
        public static bool ValidateSeller(Seller seller)
        {
            bool isValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Validation for Seller Id -should contain only digits
                if (!Regex.IsMatch(seller.SellerId.ToString(), "[0-9]{5,}"))
                {
                    message.Append("Seller Id should not contain characters \n");
                    isValidated = false;
                }

                //Validation for Seller Id - should not be empty
                if (seller.SellerId.ToString() == string.Empty)
                {
                    message.Append("SellerId should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller username - should not be empty
                if (seller.UserName == string.Empty)
                {
                    message.Append("Seller username should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller username  - should contain only characters
                if (!Regex.IsMatch(seller.UserName, "[A-Z][a-z]{3,}"))
                {
                    message.Append("Seller username should not contain digits \n");
                }

                //Validation for Seller First name - should not be empty
                if (seller.FirstName == string.Empty)
                {
                    message.Append("Seller First Name should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller Firstname  - should contain only characters
                if (!Regex.IsMatch(seller.FirstName, "[A-Z][a-z]{3,}"))
                {
                    message.Append("Seller FirstName should not contain digits \n");
                }

                // Validation for Seller lastname - can be emp[ty or should contain only characters
                if (!Regex.IsMatch(seller.LastName, "[A-Z][a-z]{0,}"))
                {
                    message.Append("Seller Lastname should not contain digits \n");
                }

                //Validation for Seller Date of birth - should not be empty
                if (seller.DateOfBirth.ToString() == string.Empty)
                {
                    message.Append("Seller Date of Birth should not be Empty");
                }

                ////Validation for Seller's age - should be more than 21 years
                //if (DateTime.Now.Year - seller.DateOfBirth.Year >= 21)
                //{
                //    message.Append("Seller doesnot have enough age,minimum age is ' 21 ' \n");
                //}

                //Validation for Seller phone no. - should start with 6/7/8/9 and should contain 10 digits
                if (!Regex.IsMatch(seller.PhoneNo.ToString(), "[6,7,8,9][0-9]{9,}"))
                {
                    message.Append("seller phone number should not contain characters and should be 10 digits \n");
                    isValidated = false;
                }

                //Validation for Seller phone no. - should not be empty 
                if (seller.PhoneNo.ToString() == string.Empty)
                {
                    message.Append("seller phone number should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller Address - should not be empty 
                if (seller.Address == string.Empty)
                {
                    message.Append("seller Address should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller StateId - should not be empty 
                if (seller.StateId.ToString() == string.Empty)
                {
                    message.Append("seller State id should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller StateId - should contain digits 
                if (!Regex.IsMatch(seller.StateId.ToString(),"[0-9]{2,}"))
                {
                    message.Append("seller StateId should contain only digits \n");
                    isValidated = false;
                }

                //Validation for Seller CityId - should not be empty 
                if (seller.CityId.ToString() == string.Empty)
                {
                    message.Append("seller City Id should not be empty \n");
                    isValidated = false;
                }

                //Validation for Seller CityId - should contain digits 
                if (!Regex.IsMatch(seller.CityId.ToString(), "[0-9]{2,}"))
                {
                    message.Append("seller City Id should contain only digits \n");
                    isValidated = false;
                }

                //Validation for seller Email Id
                if (!Regex.IsMatch(seller.EmailId.ToString(), "[A-Z,a-z][0-9,a-z,A-Z]{5,}[@]{1} "))
                {
                    message.Append("Email id is not valid, should be of form 'someone@something.com' \n");
                    isValidated = false;
                }

                //Validation for seller Email ID - should not be empty
                if (seller.EmailId == string.Empty)
                {
                    message.Append("Buyer Email Id should not be empty \n");
                    isValidated = false;
                }

                if (isValidated == false)
                    throw new SellerException(message.ToString());
            }
            catch (SellerException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return isValidated;
        }


        //Adding Seller details method
        public int AddSeller_BL(Seller newSeller)
        {
            int rowsAffected = 0;
            try
            {
                if (ValidateSeller(newSeller))
                {
                    rowsAffected = AddSeller_DAL(newSeller);
                }
            }
            catch (SellerException ex) { throw ex; }
            catch (SqlException ex) { throw ex; }
            catch (Exception ex) { throw ex; }
            return rowsAffected;
        }



    }
}

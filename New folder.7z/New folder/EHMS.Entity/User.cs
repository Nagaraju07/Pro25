﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold USER properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>

namespace EHMS.Entity
{
    public class User
    {
        //public propperty to store UserName of user
        public string UserName { get; set; }
        //public property to store Password of User
        public string Password { get; set; }
        //public property to store UserType -- that is buyer , seller or admin
        public string  UserType { get; set; }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold SELLER properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>
namespace EHMS.Entity
{
    public class Seller
    {
        //prop to store seller id
        public int SellerId { get; set; }
        //porp to store user name of seller
        public string UserName { get; set; }
        //prop to store first name of seller
        public string FirstName { get; set; }
        //prop ro store last name of seller
        public string LastName { get; set; }
        //prop to store date of birth of seller
        public DateTime DateOfBirth { get; set; }
        //prop to store phone no of seller
        public string PhoneNo { get; set; }
        //porp to store address of the seller
        public string Address { get; set; }
        //prop to store stateId of seller
        public int StateId { get; set; }
        //prop to store city id of seller
        public int CityId { get; set; }
        //prop to store email id of seller
        public string EmailId { get; set; }
        
    }
}

﻿using System;

using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold PROPPERTY properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>
namespace EHMS.Entity
{
     public    class Property
    {
        //prop to store PropertyID 
        public int PropertyId { get; set; }
        //prop to store the Name of property to be sold
        public string PropertyName { get; set; }
        //prop to store the Type Of property
        public string PropertyType { get; set; }
        //prop to store property option
        public string PropertyOption { get; set; }
        //prop to store property description
        public string Description { get; set; }
        //prop ro stpre address of property
        public string  Address { get; set; }
        //prop to store price range
        public decimal PriceRange { get; set; }
        //prop to store initial deposit amt
        public decimal InitialDeposit { get; set; }
        //prop to store landmark
        public string Landmark { get; set; }
        //prop to store state of property
        public bool IsActive { get; set; }
        //porp to store sellerId associated with property
        public int SelletId { get; set; }
        
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold CITY properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>
namespace EHMS.Entity
{
    class City
    {
        //public prop to store City of 
        public int CityId { get; set; }
        //public property to store City Name
        public string CityName { get; set; }
 
    }
}

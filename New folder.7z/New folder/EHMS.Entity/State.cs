﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold STATE properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>
namespace EHMS.Entity
{
    class State
    {
        //public propperty to store StateId 
        public int StateId { get; set; }
        //public property to store State Name
        public string  StateName { get; set; }
    }
}

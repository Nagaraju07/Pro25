﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold BUYER properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>
namespace EHMS.Entity
{
    public class Buyer
    {
        //prop to store Buyer Id
        public int BuyerId { get; set; }
        //prop to store First Name of Buyer
        public string FirstName { get; set; }
        //prop to store Last Name of buyer
        public string LastName { get; set; }
        //porp to store date of birth of buyer
        public DateTime DateOfBirth { get; set; }
        //prop to store phone number of buyer
        public string PhoneNo { get; set; }
        //prop to store email id of buyer
        public string EmailId { get; set; }

    }
}

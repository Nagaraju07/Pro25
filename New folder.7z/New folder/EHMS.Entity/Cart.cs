﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
/// <summary>
/// Employee ID : 161548
/// Employee Name : Chetan Anand
/// Description : Class to hold CART properties  of EHMS 
/// Modified On : 10/20/2018
/// </summary>
namespace EHMS.Entity
{
    class Cart
    {
        //prop to store Cart Id
        public int CartId { get; set; }
        //porp to store Buyer Id
        public int BuyerId { get; set; }
        //prop to store PropertId
        public int PropertyId { get; set; }
    }
}
